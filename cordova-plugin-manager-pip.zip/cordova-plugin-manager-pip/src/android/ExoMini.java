package com.manager.pip;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/**
 * Ao vivo no projetor com ExoPlayer (Media3) e uma RESERVA configurável.
 *
 * Por quê: os testes de rede mostraram buracos de 5–15s sem dados (servidor
 * IPTV parando ou o Wi-Fi do projetor engasgando). O VideoView do Android não
 * deixa escolher o buffer, então qualquer buraco maior que ~2–3s vira
 * "Carregando". Aqui o canal só começa quando já tem `reserveMs` de vídeo
 * guardado, e depois de um engasgo espera encher a reserva de novo — o vídeo
 * fica esses segundos atrás do ao vivo, mas passa por cima dos buracos.
 *
 * Tudo que é do ExoPlayer fica nesta classe: se a biblioteca não estiver no
 * APK, o ManagerPip pega o erro e volta pro VideoView.
 */
public class ExoMini {

    public interface Listener { void send(String json); }

    private final Listener mL;
    private final int mReserveMs;
    private final Handler mH = new Handler(Looper.getMainLooper());
    private final ExoPlayer mPlayer;
    private final PlayerView mView;
    private String mUrl;
    private boolean mPlayed = false, mReleased = false, mPaused = false;
    private int mRetries = 0, mRebuffers = 0;
    private long mBufferingSince = 0;
    private Runnable mTick;

    public ExoMini(Context ctx, int reserveMs, Listener l) {
        mL = l;
        mReserveMs = Math.max(2000, reserveMs);

        // Reserva: só começa (e só volta depois de um engasgo) com mReserveMs guardado.
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(mReserveMs, mReserveMs + 15000, mReserveMs, mReserveMs)
            .setTargetBufferBytes(48 * 1024 * 1024)      // teto de memória (~1 min de FHD)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build();

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 11) ManagerTV ExoPlayer")
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(10000)   // 10s sem dados = reconecta (a reserva segura a imagem)
            .setAllowCrossProtocolRedirects(true);

        // IPTV em .ts muitas vezes começa sem quadro-chave: aceita assim mesmo
        DefaultExtractorsFactory ext = new DefaultExtractorsFactory()
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES);

        // Caiu a conexão no meio? Reconecta sozinho, sem parar o vídeo, pra sempre
        // (depois que o canal já tocou). Antes de tocar, desiste rápido de
        // canal quebrado (401/403/404) pra o app poder usar o outro player.
        LoadErrorHandlingPolicy policy = new DefaultLoadErrorHandlingPolicy() {
            @Override
            public long getRetryDelayMsFor(LoadErrorHandlingPolicy.LoadErrorInfo info) {
                if (!mPlayed) {
                    if (info.exception instanceof HttpDataSource.InvalidResponseCodeException) {
                        int c = ((HttpDataSource.InvalidResponseCodeException) info.exception).responseCode;
                        if (c == 401 || c == 403 || c == 404 || c == 405 || c == 410) return C.TIME_UNSET;
                    }
                    if (info.errorCount > 4) return C.TIME_UNSET;
                }
                send("{\"event\":\"netretry\",\"n\":" + info.errorCount + ",\"why\":" + q(String.valueOf(info.exception)) + "}");
                return Math.min(1000L * info.errorCount, 5000L);
            }
            @Override
            public int getMinimumLoadableRetryCount(int dataType) { return Integer.MAX_VALUE; }
        };

        mPlayer = new ExoPlayer.Builder(ctx)
            .setLoadControl(lc)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(http, ext).setLoadErrorHandlingPolicy(policy))
            .build();

        mView = new PlayerView(ctx);
        mView.setUseController(false);
        mView.setFocusable(false);
        mView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        mView.setShutterBackgroundColor(Color.BLACK);
        mView.setKeepContentOnPlayerReset(true);
        mView.setPlayer(mPlayer);

        mPlayer.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (mReleased) return;
                if (state == Player.STATE_BUFFERING) {
                    mBufferingSince = System.currentTimeMillis();
                    if (mPlayed) { mRebuffers++; send("{\"event\":\"buffering\",\"n\":" + mRebuffers + "}"); }
                } else if (state == Player.STATE_READY) {
                    mBufferingSince = 0;
                    mRetries = 0;
                    if (!mPlayed) { mPlayed = true; send("{\"event\":\"playing\",\"reserve\":" + mReserveMs + "}"); }
                    else send("{\"event\":\"buffered\"}");
                } else if (state == Player.STATE_ENDED) {
                    retry("o stream terminou");
                }
            }
            @Override
            public void onPlayerError(PlaybackException e) {
                if (mReleased) return;
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    mPlayer.seekToDefaultPosition();
                    mPlayer.prepare();
                    return;
                }
                send("{\"event\":\"error\",\"what\":" + q(e.getErrorCodeName()) + ",\"extra\":" + q(String.valueOf(e.getMessage())) + "}");
                if (!mPlayed && mRetries >= 1) { send("{\"event\":\"failed\",\"err\":" + q(e.getErrorCodeName()) + "}"); return; }
                retry(e.getErrorCodeName());
            }
        });

        // a cada 2s: quanto tem guardado (o app mostra "Enchendo reserva X/Ys")
        // e vigia: preso carregando muito tempo = reconecta do zero
        mTick = new Runnable() {
            public void run() {
                if (mReleased) return;
                try {
                    long buf = mPlayer.getTotalBufferedDuration();
                    int st = mPlayer.getPlaybackState();
                    send("{\"event\":\"stat\",\"buf\":" + buf + ",\"reserve\":" + mReserveMs + ",\"state\":" + st + ",\"played\":" + mPlayed + "}");
                    if (!mPaused && st == Player.STATE_BUFFERING && mBufferingSince > 0
                            && System.currentTimeMillis() - mBufferingSince > Math.max(30000, mReserveMs + 20000)) {
                        mBufferingSince = System.currentTimeMillis();
                        retry("sem dados há muito tempo");
                    }
                } catch (Throwable ignore) {}
                mH.postDelayed(this, 2000);
            }
        };
        mH.postDelayed(mTick, 2000);
    }

    public View view() { return mView; }

    public void play(String url) {
        mUrl = url;
        mPlayed = false; mRetries = 0; mRebuffers = 0;
        load();
        mPlayer.setPlayWhenReady(!mPaused);
    }

    private void load() {
        MediaItem.Builder b = new MediaItem.Builder()
            .setUri(mUrl)
            .setLiveConfiguration(new MediaItem.LiveConfiguration.Builder().setTargetOffsetMs(mReserveMs).build());
        String low = mUrl.toLowerCase();
        if (low.contains(".m3u8") || low.contains("output=hls") || low.contains("type=m3u8")) b.setMimeType(MimeTypes.APPLICATION_M3U8);
        mPlayer.setMediaItem(b.build());
        mPlayer.prepare();
    }

    private void retry(String why) {
        if (mReleased) return;
        mRetries++;
        long wait = Math.min(10000L, 1500L * mRetries);
        send("{\"event\":\"retry\",\"n\":" + mRetries + ",\"why\":" + q(why) + "}");
        mH.postDelayed(new Runnable() {
            public void run() {
                if (mReleased) return;
                try { mPlayer.stop(); } catch (Throwable ignore) {}
                load();
                mPlayer.setPlayWhenReady(!mPaused);
            }
        }, wait);
    }

    public void pause() { mPaused = true; mPlayer.setPlayWhenReady(false); }
    public void resume() { mPaused = false; mBufferingSince = 0; mPlayer.setPlayWhenReady(true); }
    public void volume(float v) { mPlayer.setVolume(v); }

    public void release() {
        mReleased = true;
        mH.removeCallbacksAndMessages(null);
        try { mView.setPlayer(null); } catch (Throwable ignore) {}
        try { mPlayer.release(); } catch (Throwable ignore) {}
    }

    private static String q(String s) { return org.json.JSONObject.quote(s == null ? "" : s); }

    private void send(String json) { if (!mReleased && mL != null) mL.send(json); }
}
