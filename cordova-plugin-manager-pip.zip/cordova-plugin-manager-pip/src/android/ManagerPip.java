package com.manager.pip;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;
import android.app.PictureInPictureParams;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Rational;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

import android.app.Dialog;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.content.DialogInterface;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.net.TrafficStats;
import android.view.ViewGroup;
import org.apache.cordova.PluginResult;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ManagerPip extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, final CallbackContext callback) throws JSONException {
        // ---------- MINI PLAYER NATIVO (quadro do Ao Vivo, por cima do app) ----------
        // Um VideoView do Android posicionado em cima do quadro da página. Não
        // pega foco: as setas continuam navegando no app.
        if ("miniShow".equals(action) || "miniMove".equals(action)) {
            final boolean show = "miniShow".equals(action);
            final String url = show ? args.getString(0) : null;
            final int off = show ? 1 : 0;
            final int x = args.optInt(off), y = args.optInt(off + 1), w = args.optInt(off + 2), h = args.optInt(off + 3);
            final boolean visible = args.optBoolean(off + 4, true);
            final String bg = show ? args.optString(off + 5, "#0B0D16") : null;
            // reserva do ExoPlayer em ms (>= 0 = usar ExoPlayer; -1 ou ausente = VideoView antigo)
            final int reserve = show ? args.optInt(off + 6, -1) : -1;
            // endereço reserva (.ts) caso o principal (HLS) não abra no ExoPlayer
            final String fb = show ? args.optString(off + 7, "") : "";
            // projetor: modo rápido de reconexão (Wi-Fi que troca de faixa)
            final boolean fast = show && args.optBoolean(off + 8, false);
            if (show) mCb = callback;
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (show) miniOpen(url, bg, reserve, fb, fast);
                        miniPlace(x, y, w, h, visible);
                        if (!show) callback.success();
                    } catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
                }
            });
            return true;
        }
        // controles do player híbrido (os botões são do app, o vídeo é nativo)
        if ("miniPause".equals(action) || "miniResume".equals(action) || "miniVolume".equals(action)) {
            final String act = action;
            final float vol = (float) args.optDouble(0, 1.0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (mExo != null) {
                            if ("miniPause".equals(act)) { mPaused = true; mExo.pause(); }
                            else if ("miniResume".equals(act)) { mPaused = false; mExo.resume(); }
                            else { mVol = vol; mExo.volume(vol); }
                        } else if (mView != null) {
                            if ("miniPause".equals(act)) { mPaused = true; mView.pause(); }
                            else if ("miniResume".equals(act)) { mPaused = false; mLastMove = System.currentTimeMillis(); mView.start(); }
                            else { mVol = vol; if (mMp != null) mMp.setVolume(vol, vol); }
                        }
                        callback.success();
                    } catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
                }
            });
            return true;
        }
        if ("miniHide".equals(action)) {
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() { miniClose("hidden"); callback.success(); }
            });
            return true;
        }
        // ---------- PLAYER NATIVO (tela cheia, fora do WebView) ----------
        // O Android toca o stream sozinho (TS ou HLS, com o chip de vídeo) —
        // sem JavaScript convertendo o vídeo. Voltar fecha e devolve pro app.
        // bytes recebidos pela rede (este app, inclusive o player nativo, e o
        // aparelho todo) — o app calcula a velocidade a cada 2s (rodapé)
        if ("netStats".equals(action)) {
            try {
                JSONObject o = new JSONObject();
                o.put("app", TrafficStats.getUidRxBytes(android.os.Process.myUid()));
                o.put("total", TrafficStats.getTotalRxBytes());
                callback.success(o);
            } catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
            return true;
        }
        // ---------- WI-FI ----------
        // wifiLock [true|false]: pede pro Android NÃO pôr o Wi-Fi em economia
        // de energia enquanto o app está aberto (modo alto desempenho e, no
        // Android 10+, baixa latência). Solta sozinho quando o app fecha.
        if ("wifiLock".equals(action)) {
            try {
                boolean on = args.optBoolean(0, true);
                setWifiLock(on);
                callback.success(wifiJson());
            } catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
            return true;
        }
        // wifiInfo: sinal (dBm), velocidade do link, frequência (2.4/5 GHz),
        // se a trava está ligada e os eventos de rede (quando o Android
        // disse que a rede caiu/voltou), com horário.
        if ("wifiInfo".equals(action)) {
            try { watchNetwork(); callback.success(wifiJson()); }
            catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
            return true;
        }
        if ("hasNativePlayer".equals(action)) {
            callback.success(1);
            return true;
        }
        if ("playVideo".equals(action)) {
            final String url = args.getString(0);
            final String title = args.optString(1, "");
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try { openPlayer(url, title, callback); }
                    catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
                }
            });
            return true;
        }
        if ("stopVideo".equals(action)) {
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() { closePlayer("stopped"); callback.success(); }
            });
            return true;
        }
        if ("isSupported".equals(action)) {
            callback.success(isSupported() ? 1 : 0);
            return true;
        }
        if ("enter".equals(action)) {
            final int w = args.optInt(0, 16);
            final int h = args.optInt(1, 9);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (!isSupported()) {
                            callback.error("PiP nao suportado neste aparelho (precisa Android 8.0+ com PiP liberado)");
                            return;
                        }
                        if (enterPip(w, h)) callback.success();
                        else callback.error("O Android recusou o PiP (confira se o PiP esta permitido pro app nas configuracoes)");
                    } catch (Throwable t) {
                        callback.error(t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            });
            return true;
        }
        // Limpa o cache HTTP do WebView (arquivos baixados da internet que o
        // navegador interno guarda). Não mexe em IndexedDB/localStorage.
        if ("clearCache".equals(action)) {
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        android.view.View v = webView.getView();
                        if (v instanceof android.webkit.WebView) ((android.webkit.WebView) v).clearCache(true);
                        else webView.clearCache();
                        callback.success();
                    } catch (Throwable t) {
                        callback.error(t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            });
            return true;
        }
        // Memória RAM do aparelho (pro painel de diagnóstico do app):
        // total, livre, se o Android está em "pouca memória" e quanto este
        // app (processo principal) está usando.
        // sysStats: memória livre do aparelho + contadores de CPU (rodapé do app).
        // Rápido: não usa Debug.getMemoryInfo. CPU: /proc/stat (aparelho todo);
        // se o Android bloquear (8+ costuma bloquear), manda o tempo de CPU do app.
        if ("sysStats".equals(action)) {
            cordova.getThreadPool().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        ActivityManager am = (ActivityManager) cordova.getActivity().getSystemService(Context.ACTIVITY_SERVICE);
                        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                        am.getMemoryInfo(mi);
                        JSONObject o = new JSONObject();
                        o.put("avail", mi.availMem);
                        o.put("total", mi.totalMem);
                        o.put("cores", Runtime.getRuntime().availableProcessors());
                        try {
                            String[] f = firstLine("/proc/stat").trim().split("\\s+");
                            long idle = Long.parseLong(f[4]) + (f.length > 5 ? Long.parseLong(f[5]) : 0);
                            long tot = 0;
                            for (int i = 1; i < f.length && i <= 8; i++) tot += Long.parseLong(f[i]);
                            o.put("cpuIdle", idle);
                            o.put("cpuTotal", tot);
                        } catch (Throwable blocked) {
                            try {
                                String st = firstLine("/proc/self/stat");
                                String[] f = st.substring(st.lastIndexOf(')') + 2).split(" ");
                                o.put("selfTicks", Long.parseLong(f[11]) + Long.parseLong(f[12]));
                            } catch (Throwable ignore) {}
                        }
                        callback.success(o);
                    } catch (Throwable t) { callback.error(t.getClass().getSimpleName() + ": " + t.getMessage()); }
                }
            });
            return true;
        }
        if ("memInfo".equals(action)) {
            // Roda FORA da thread da ponte JS<->Java: Debug.getMemoryInfo é
            // lento (centenas de ms num aparelho fraco) e, na thread da ponte,
            // travava a página inteira a cada leitura.
            cordova.getThreadPool().execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        ActivityManager am = (ActivityManager) cordova.getActivity().getSystemService(Context.ACTIVITY_SERVICE);
                        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                        am.getMemoryInfo(mi);
                        JSONObject o = new JSONObject();
                        o.put("total", mi.totalMem);
                        o.put("avail", mi.availMem);
                        o.put("low", mi.lowMemory);
                        o.put("threshold", mi.threshold);
                        Debug.MemoryInfo dm = new Debug.MemoryInfo();
                        Debug.getMemoryInfo(dm);
                        o.put("appPssKb", dm.getTotalPss());
                        callback.success(o);
                    } catch (Throwable t) {
                        callback.error(t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            });
            return true;
        }
        // Tela cheia de verdade no APK: esconde barra de status e de navegação
        // (o requestFullscreen do WebView sozinho não esconde a barra de status).
        if ("immersive".equals(action) || "showSystemUI".equals(action)) {
            final boolean on = "immersive".equals(action);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        setImmersive(on);
                        callback.success();
                    } catch (Throwable t) {
                        callback.error(t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            });
            return true;
        }
        return false;
    }

    @SuppressWarnings("deprecation")
    private void setImmersive(boolean on) {
        Window w = cordova.getActivity().getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            setImmersiveApi30(w, on);
            return;
        }
        View d = w.getDecorView();
        if (on) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } else {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @TargetApi(30)
    private void setImmersiveApi30(Window w, boolean on) {
        WindowInsetsController c = w.getInsetsController();
        if (c == null) return;
        int bars = WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars();
        if (on) {
            c.hide(bars);
            // puxar da borda mostra as barras só por um instante
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            c.show(bars);
        }
    }

    private boolean isSupported() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        return cordova.getActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
    }

    @TargetApi(Build.VERSION_CODES.O)
    private boolean enterPip(int w, int h) {
        Activity activity = cordova.getActivity();
        w = Math.max(1, w);
        h = Math.max(1, h);
        // O Android só aceita proporções entre 1:2.39 e 2.39:1.
        float ratio = (float) w / (float) h;
        Rational r;
        if (ratio > 2.39f) r = new Rational(239, 100);
        else if (ratio < 1f / 2.39f) r = new Rational(100, 239);
        else r = new Rational(w, h);
        PictureInPictureParams params = new PictureInPictureParams.Builder().setAspectRatio(r).build();
        return activity.enterPictureInPictureMode(params);
    }

    // ================== PLAYER NATIVO ==================
    private Dialog pDialog;
    private VideoView pView;
    private TextView pLabel;
    private CallbackContext pCb;
    private final Handler pH = new Handler(Looper.getMainLooper());
    private int pRetries = 0;
    private boolean pEverPlayed = false;
    private int pLastPos = -1;
    private long pLastMove = 0;
    private String pUrl, pTitle;
    private Runnable pWatch, pHideLabel;

    private void pSend(String json, boolean keep) {
        if (pCb == null) return;
        PluginResult r = new PluginResult(PluginResult.Status.OK, json);
        r.setKeepCallback(keep);
        pCb.sendPluginResult(r);
        if (!keep) pCb = null;
    }
    private static String firstLine(String path) throws java.io.IOException {
        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(path));
        try { String l = r.readLine(); if (l == null) throw new java.io.IOException("vazio"); return l; }
        finally { try { r.close(); } catch (Throwable ignore) {} }
    }

    private static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    private void pLabel(String text, boolean autoHide) {
        if (pLabel == null) return;
        pLabel.setText(text);
        pLabel.setVisibility(View.VISIBLE);
        if (pHideLabel != null) pH.removeCallbacks(pHideLabel);
        if (autoHide) {
            pHideLabel = new Runnable() { public void run() { if (pLabel != null) pLabel.setVisibility(View.GONE); } };
            pH.postDelayed(pHideLabel, 4000);
        }
    }

    private void openPlayer(String url, String title, CallbackContext cb) {
        closePlayer("replaced");
        miniClose("fullscreen"); // libera o decodificador pro vídeo em tela cheia
        pCb = cb; pUrl = url; pTitle = title; pRetries = 0; pEverPlayed = false; pLastPos = -1; pLastMove = System.currentTimeMillis();
        Activity act = cordova.getActivity();
        final Dialog d = new Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout root = new FrameLayout(act);
        root.setBackgroundColor(Color.BLACK);
        final VideoView v = new VideoView(act);
        root.addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        TextView t = new TextView(act);
        t.setTextColor(Color.WHITE); t.setTextSize(18); t.setPadding(36, 22, 36, 22);
        t.setBackgroundColor(0xAA000000);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.LEFT);
        tl.setMargins(30, 30, 30, 30);
        root.addView(t, tl);
        d.setContentView(root);
        pDialog = d; pView = v; pLabel = t;
        pLabel(title + "  •  carregando...", false);

        v.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                pEverPlayed = true; pRetries = 0; pLastMove = System.currentTimeMillis();
                pLabel(pTitle, true);
                mp.start();
                pSend("{\"event\":\"playing\"}", true);
            }
        });
        v.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) pLabel(pTitle + "  •  carregando...", false);
                else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END || what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) pLabel(pTitle, true);
                return false;
            }
        });
        v.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                pSend("{\"event\":\"error\",\"what\":" + what + ",\"extra\":" + extra + "}", true);
                // nunca tocou e já falhou 2x: esse formato o Android não abre — devolve pro app tentar do jeito dele
                if (!pEverPlayed && pRetries >= 1) { closePlayer("failed"); return true; }
                retry("erro " + what + "/" + extra);
                return true;
            }
        });
        v.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) { retry("o stream terminou"); } // ao vivo não "termina": reconecta
        });
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            public boolean onKey(DialogInterface di, int keyCode, KeyEvent ev) {
                if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                    if (ev.getAction() == KeyEvent.ACTION_UP) closePlayer("closed");
                    return true;
                }
                if ((keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) && ev.getAction() == KeyEvent.ACTION_UP) {
                    pLabel(pTitle, true); // mostra o nome do canal
                    return true;
                }
                return false;
            }
        });
        d.setOnCancelListener(new DialogInterface.OnCancelListener() {
            public void onCancel(DialogInterface di) { closePlayer("closed"); }
        });
        d.show();
        try {
            Window w = d.getWindow();
            if (w != null) {
                w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
                w.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        } catch (Throwable ignore) {}
        v.setVideoURI(Uri.parse(url));
        v.start();
        // vigia: vídeo parado ~15s (sem erro) = reconecta
        pWatch = new Runnable() {
            public void run() {
                if (pView == null) return;
                try {
                    int pos = pView.getCurrentPosition();
                    if (pos != pLastPos) { pLastPos = pos; pLastMove = System.currentTimeMillis(); }
                    else if (System.currentTimeMillis() - pLastMove > 15000) { pLastMove = System.currentTimeMillis(); retry("vídeo parado"); }
                } catch (Throwable ignore) {}
                pH.postDelayed(this, 3000);
            }
        };
        pH.postDelayed(pWatch, 3000);
    }

    private void retry(String why) {
        if (pView == null) return;
        pRetries++;
        long wait = Math.min(10000, 1500L * pRetries);
        pLabel(pTitle + "  •  reconectando (tentativa " + pRetries + ")...", false);
        pSend("{\"event\":\"retry\",\"n\":" + pRetries + ",\"why\":" + q(why) + "}", true);
        pH.postDelayed(new Runnable() {
            public void run() {
                if (pView == null) return;
                try { pView.stopPlayback(); } catch (Throwable ignore) {}
                pLastMove = System.currentTimeMillis();
                pView.setVideoURI(Uri.parse(pUrl));
                pView.start();
            }
        }, wait);
    }

    private void closePlayer(String reason) {
        if (pWatch != null) { pH.removeCallbacks(pWatch); pWatch = null; }
        if (pHideLabel != null) { pH.removeCallbacks(pHideLabel); pHideLabel = null; }
        pH.removeCallbacksAndMessages(null);
        if (pView != null) { try { pView.stopPlayback(); } catch (Throwable ignore) {} pView = null; }
        if (pDialog != null) { try { pDialog.setOnCancelListener(null); pDialog.dismiss(); } catch (Throwable ignore) {} pDialog = null; }
        pLabel = null;
        if (pCb != null) pSend("{\"event\":" + q(reason) + ",\"played\":" + pEverPlayed + "}", false);
    }

    // ================== MINI PLAYER NATIVO ==================
    private FrameLayout mBox;
    private VideoView mView;
    private ExoMini mExo;
    /** Cor de fundo do app. O WebView do Cordova é BRANCO por padrão: com a
     *  página transparente (buraco do ao vivo) qualquer instante sem o vídeo
     *  por trás aparecia branco. Pinta tudo por trás com a cor do app. */
    private int mAppBg = 0xFF0B0D16;

    private void paintAppBg(Activity act, ViewGroup content) {
        try { if (content != null) content.setBackgroundColor(mAppBg); } catch (Throwable ignore) {}
        try { act.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(mAppBg)); } catch (Throwable ignore) {}
    }

    @Override
    protected void pluginInitialize() {
        // ao abrir o app: fundo escuro em vez do branco padrão do WebView
        final Activity act = cordova.getActivity();
        act.runOnUiThread(new Runnable() {
            public void run() {
                try { webView.getView().setBackgroundColor(mAppBg); } catch (Throwable ignore) {}
                paintAppBg(act, (ViewGroup) act.findViewById(android.R.id.content));
            }
        });
    }
    private String mVvUrl;          // ExoPlayer com reserva (projetor, ao vivo)
    private CallbackContext mCb;
    private String mUrl;
    private int mRetries = 0, mLastPos = -1;
    private boolean mPlayed = false, mPaused = false;
    private MediaPlayer mMp;
    private float mVol = 1f;
    private long mLastMove = 0;
    private Runnable mWatch;
    private final Handler mH = new Handler(Looper.getMainLooper());

    private void mSend(String json, boolean keep) {
        if (mCb == null) return;
        PluginResult r = new PluginResult(PluginResult.Status.OK, json);
        r.setKeepCallback(keep);
        mCb.sendPluginResult(r);
        if (!keep) mCb = null;
    }

    /** O vídeo fica ATRÁS do WebView (que fica transparente só onde a página
     *  deixa um "buraco" no quadro). Assim tudo da página — painel de
     *  diagnóstico, popups, avisos — aparece POR CIMA do vídeo. O fundo da
     *  tela nativa ganha a cor de fundo do app, então o resto fica igual. */
    private void miniOpen(String url, String bg, int reserveMs, String fallback, boolean fast) {
        Activity act = cordova.getActivity();
        ViewGroup content = (ViewGroup) act.findViewById(android.R.id.content);
        if (mBox == null) {
            mBox = new FrameLayout(act);
            mBox.setBackgroundColor(Color.BLACK);
            mBox.setFocusable(false);
            content.addView(mBox, 0, new FrameLayout.LayoutParams(1, 1, Gravity.TOP | Gravity.LEFT));
            try { mAppBg = Color.parseColor(bg == null ? "#0B0D16" : bg); } catch (Throwable t) { mAppBg = 0xFF0B0D16; }
            paintAppBg(act, content);
            try { webView.getView().setBackgroundColor(Color.TRANSPARENT); } catch (Throwable ignore) {}
        }
        if (url.equals(mUrl) && (mView != null || mExo != null)) {
            // já tocando esse canal (ex.: estava na prévia do quadro): avisa o app
            // que está tocando, senão a bolinha de carregando fica por cima do vídeo
            boolean on = mExo != null ? mExo.played() : mPlayed;
            if (on) mSend("{\"event\":\"playing\",\"same\":true}", true);
            return;
        }
        if (mView != null) { try { mView.stopPlayback(); } catch (Throwable ignore) {} mBox.removeView(mView); mView = null; }
        if (mExo != null) { try { mExo.release(); mBox.removeView(mExo.view()); } catch (Throwable ignore) {} mExo = null; }
        mUrl = url; mRetries = 0; mPlayed = false; mPaused = false; mMp = null; mLastPos = -1; mLastMove = System.currentTimeMillis();
        if (reserveMs >= 0) {
            // ExoPlayer com reserva; se a biblioteca não estiver no APK, cai no VideoView
            try {
                final ExoMini[] self = new ExoMini[1];
                if (fast) watchNetwork();
                final ExoMini ex = new ExoMini(act, reserveMs, new ExoMini.Listener() {
                    public void send(String json) {
                        if (json.startsWith("{\"event\":\"failed\"")) { mH.post(new Runnable() { public void run() { if (mExo != null && mExo == self[0]) miniClose("failed"); } }); return; }
                        if (json.startsWith("{\"event\":\"playing\"")) mPlayed = true;
                        mSend(json, true);
                    }
                }, fast);
                mBox.addView(ex.view(), new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
                self[0] = ex;
                mExo = ex;
                ex.volume(mVol);
                ex.play(url, fallback);
                mSend("{\"event\":\"engine\",\"name\":\"exoplayer\",\"reserve\":" + reserveMs + "}", true);
                return;
            } catch (Throwable t) {
                if (mExo != null) { try { mExo.release(); mBox.removeView(mExo.view()); } catch (Throwable ignore) {} }
                mExo = null;
                mSend("{\"event\":\"engine\",\"name\":\"videoview\",\"why\":" + q(t.getClass().getSimpleName() + ": " + t.getMessage()) + "}", true);
            }
        }
        // VideoView antigo: usa o .ts (como sempre usou), não o HLS
        mVvUrl = (fallback != null && fallback.length() > 0) ? fallback : url;
        final VideoView v = new VideoView(act);
        v.setFocusable(false);
        mBox.addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        mView = v;
        v.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                mMp = mp; mPlayed = true; mRetries = 0; mLastMove = System.currentTimeMillis();
                try { mp.setVolume(mVol, mVol); } catch (Throwable ignore) {}
                if (!mPaused) mp.start();
                mSend("{\"event\":\"playing\"}", true);
            }
        });
        v.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) mSend("{\"event\":\"buffering\"}", true);
                else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END || what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) mSend("{\"event\":\"buffered\"}", true);
                return false;
            }
        });
        v.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                mSend("{\"event\":\"error\",\"what\":" + what + ",\"extra\":" + extra + "}", true);
                if (!mPlayed && mRetries >= 1) { miniClose("failed"); return true; }
                miniRetry("erro " + what + "/" + extra);
                return true;
            }
        });
        v.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) { miniRetry("o stream terminou"); }
        });
        v.setVideoURI(Uri.parse(mVvUrl));
        v.start();
        if (mWatch == null) {
            mWatch = new Runnable() {
                public void run() {
                    if (mView == null) { mWatch = null; return; }
                    try {
                        int pos = mView.getCurrentPosition();
                        if (mPaused) { mLastMove = System.currentTimeMillis(); }
                        else if (pos != mLastPos) { mLastPos = pos; mLastMove = System.currentTimeMillis(); }
                        else if (System.currentTimeMillis() - mLastMove > 15000) { mLastMove = System.currentTimeMillis(); miniRetry("vídeo parado"); }
                    } catch (Throwable ignore) {}
                    mH.postDelayed(this, 3000);
                }
            };
            mH.postDelayed(mWatch, 3000);
        }
    }

    /** x/y/w/h em pixels CSS * densidade, relativos ao WebView */
    private void miniPlace(int x, int y, int w, int h, boolean visible) {
        if (mBox == null) return;
        int ox = 0, oy = 0;
        try {
            int[] wl = new int[2], cl = new int[2];
            webView.getView().getLocationInWindow(wl);
            ((View) mBox.getParent()).getLocationInWindow(cl);
            ox = wl[0] - cl[0]; oy = wl[1] - cl[1];
        } catch (Throwable ignore) {}
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(1, w), Math.max(1, h), Gravity.TOP | Gravity.LEFT);
        lp.setMargins(ox + x, oy + y, 0, 0);
        mBox.setLayoutParams(lp);
        mBox.setVisibility(visible && w > 2 && h > 2 ? View.VISIBLE : View.INVISIBLE);
    }

    private void miniRetry(String why) {
        if (mView == null) return;
        mRetries++;
        long wait = Math.min(10000, 1500L * mRetries);
        mSend("{\"event\":\"retry\",\"n\":" + mRetries + ",\"why\":" + q(why) + "}", true);
        mH.postDelayed(new Runnable() {
            public void run() {
                if (mView == null) return;
                try { mView.stopPlayback(); } catch (Throwable ignore) {}
                mMp = null;
                mLastMove = System.currentTimeMillis();
                mView.setVideoURI(Uri.parse(mVvUrl));
                mView.start();
            }
        }, wait);
    }

    // ---------- Wi-Fi: trava + informações + eventos de rede ----------
    private android.net.wifi.WifiManager.WifiLock mWifiHp, mWifiLl;
    private boolean mNetWatching = false;
    private Boolean mValidated = null;
    private final java.util.ArrayList<String> mNetEvents = new java.util.ArrayList<String>();

    private android.net.wifi.WifiManager wifi() {
        return (android.net.wifi.WifiManager) cordova.getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    private synchronized void setWifiLock(boolean on) {
        android.net.wifi.WifiManager wm = wifi();
        if (on) {
            if (mWifiHp == null) {
                mWifiHp = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "Manager:hp");
                mWifiHp.setReferenceCounted(false);
            }
            if (!mWifiHp.isHeld()) mWifiHp.acquire();
            if (Build.VERSION.SDK_INT >= 29) {
                if (mWifiLl == null) {
                    mWifiLl = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "Manager:ll");
                    mWifiLl.setReferenceCounted(false);
                }
                if (!mWifiLl.isHeld()) mWifiLl.acquire();
            }
            netEvent("trava do Wi-Fi LIGADA");
        } else {
            try { if (mWifiHp != null && mWifiHp.isHeld()) mWifiHp.release(); } catch (Throwable ignore) {}
            try { if (mWifiLl != null && mWifiLl.isHeld()) mWifiLl.release(); } catch (Throwable ignore) {}
            netEvent("trava do Wi-Fi desligada");
        }
    }

    private synchronized void netEvent(String what) {
        mNetEvents.add(System.currentTimeMillis() + "|" + what);
        while (mNetEvents.size() > 60) mNetEvents.remove(0);
    }

    private synchronized void watchNetwork() {
        if (mNetWatching) return;
        mNetWatching = true;
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) cordova.getActivity().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.NetworkRequest req = new android.net.NetworkRequest.Builder()
                .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            cm.registerNetworkCallback(req, new android.net.ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(android.net.Network n) {
                    netEvent("rede conectada");
                    mH.post(new Runnable() { public void run() { if (mExo != null) mExo.networkBack(); } });
                }
                @Override public void onLost(android.net.Network n) {
                    netEvent("REDE CAIU (Android perdeu a conexão)");
                    mH.post(new Runnable() { public void run() { if (mExo != null) mExo.networkLost(); } });
                }
                @Override public void onLosing(android.net.Network n, int ms) { netEvent("rede prestes a cair"); }
                @Override public void onUnavailable() { netEvent("rede indisponível"); }
                @Override public void onCapabilitiesChanged(android.net.Network n, android.net.NetworkCapabilities c) {
                    boolean v = c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                    if (mValidated != null && mValidated != v) netEvent(v ? "internet voltou (Android validou de novo)" : "INTERNET PERDIDA (Wi-Fi conectado, mas sem internet)");
                    mValidated = v;
                }
            });
            netEvent("monitor de rede iniciado");
        } catch (Throwable t) { netEvent("monitor de rede falhou: " + t.getMessage()); }
    }

    private synchronized JSONObject wifiJson() throws JSONException {
        JSONObject o = new JSONObject();
        try {
            android.net.wifi.WifiInfo wi = wifi().getConnectionInfo();
            if (wi != null) {
                o.put("rssi", wi.getRssi());
                o.put("link", wi.getLinkSpeed());
                if (Build.VERSION.SDK_INT >= 21) o.put("freq", wi.getFrequency());
                if (Build.VERSION.SDK_INT >= 29) { o.put("rx", wi.getRxLinkSpeedMbps()); o.put("tx", wi.getTxLinkSpeedMbps()); }
                // estado da conexão com o roteador: COMPLETED = conectado;
                // SCANNING / ASSOCIATING / DISCONNECTED... = caiu ou reconectando
                try { o.put("state", String.valueOf(wi.getSupplicantState())); } catch (Throwable ignore) {}
                o.put("netId", wi.getNetworkId());
                o.put("ip", wi.getIpAddress());
            }
        } catch (Throwable t) { o.put("err", t.getMessage()); }
        try {
            o.put("wifiOn", wifi().isWifiEnabled());
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) cordova.getActivity().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) {
                android.net.Network an = cm.getActiveNetwork();
                o.put("connected", an != null);
                android.net.NetworkCapabilities nc = an != null ? cm.getNetworkCapabilities(an) : null;
                if (nc != null) o.put("validated", nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED));
            }
        } catch (Throwable ignore) {}
        o.put("lock", mWifiHp != null && mWifiHp.isHeld());
        o.put("sdk", Build.VERSION.SDK_INT);
        JSONArray ev = new JSONArray();
        for (String e : mNetEvents) ev.put(e);
        o.put("events", ev);
        return o;
    }

    @Override
    public void onDestroy() {
        try { setWifiLock(false); } catch (Throwable ignore) {}
    }

    private void miniClose(String reason) {
        mMp = null; mPaused = false;
        mH.removeCallbacksAndMessages(null);
        mWatch = null;
        if (mView != null) { try { mView.stopPlayback(); } catch (Throwable ignore) {} mView = null; }
        if (mExo != null) { try { mExo.release(); } catch (Throwable ignore) {} mExo = null; }
        if (mBox != null) { try { ((ViewGroup) mBox.getParent()).removeView(mBox); } catch (Throwable ignore) {} mBox = null; }
        // volta a cor do app (não branco nem preto) — a página pode ainda estar transparente por um instante
        try { webView.getView().setBackgroundColor(mAppBg); } catch (Throwable ignore) {}
        mUrl = null;
        if (mCb != null) mSend("{\"event\":" + q(reason) + ",\"played\":" + mPlayed + "}", false);
    }
}
