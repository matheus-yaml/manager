package com.manager.pip;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Rational;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

public class ManagerPip extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, final CallbackContext callback) throws JSONException {
        if ("isSupported".equals(action)) {
            callback.success(isSupported() ? 1 : 0);
            return true;
        }
        if ("enter".equals(action)) {
            final int w = args.optInt(0, 16);
            final int h = args.optInt(1, 9);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (!isSupported()) {
                            callback.error("PiP nao suportado neste aparelho (precisa Android 8.0+ com PiP liberado)");
                            return;
                        }
                        if (enterPip(w, h)) callback.success();
                        else callback.error("O Android recusou o PiP (confira se o PiP esta permitido pro app nas configuracoes)");
                    } catch (Throwable t) {
                        callback.error(t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            });
            return true;
        }
        return false;
    }

    private boolean isSupported() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        return cordova.getActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
    }

    @TargetApi(Build.VERSION_CODES.O)
    private boolean enterPip(int w, int h) {
        Activity activity = cordova.getActivity();
        w = Math.max(1, w);
        h = Math.max(1, h);
        // O Android só aceita proporções entre 1:2.39 e 2.39:1.
        float ratio = (float) w / (float) h;
        Rational r;
        if (ratio > 2.39f) r = new Rational(239, 100);
        else if (ratio < 1f / 2.39f) r = new Rational(100, 239);
        else r = new Rational(w, h);
        PictureInPictureParams params = new PictureInPictureParams.Builder().setAspectRatio(r).build();
        return activity.enterPictureInPictureMode(params);
    }
}
